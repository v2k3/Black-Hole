package dev.monarkhes.myron.impl.mixin;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1092.class})
public interface BakedModelManagerAccessor {
  @Accessor
  Map<class_2960, class_1087> getModels();
}


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/blackhole-1.0.1+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/mixin/BakedModelManagerAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */