/*     */ package dev.monarkhes.myron.impl.client.model;
/*     */ 
/*     */ import dev.monarkhes.myron.impl.client.Myron;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.function.Supplier;
/*     */ import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
/*     */ import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
/*     */ import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
/*     */ import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
/*     */ import net.minecraft.class_1058;
/*     */ import net.minecraft.class_1087;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1920;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_777;
/*     */ import net.minecraft.class_806;
/*     */ import net.minecraft.class_809;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class MyronBakedModel
/*     */   implements class_1087, FabricBakedModel {
/*     */   private final Mesh mesh;
/*     */   private final class_809 transformation;
/*     */   private final class_1058 sprite;
/*     */   private final boolean isSideLit;
/*  30 */   private List<class_777> backupQuads = null;
/*     */   
/*     */   public MyronBakedModel(Mesh mesh, class_809 transformation, class_1058 sprite, boolean isSideLit) {
/*  33 */     this.mesh = mesh;
/*  34 */     this.transformation = transformation;
/*  35 */     this.sprite = sprite;
/*  36 */     this.isSideLit = isSideLit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitBlockQuads(class_1920 blockRenderView, class_2680 blockState, class_2338 blockPos, Supplier<Random> supplier, RenderContext renderContext) {
/*  41 */     if (this.mesh != null) {
/*  42 */       renderContext.meshConsumer().accept(this.mesh);
/*     */     } else {
/*  44 */       Myron.LOGGER.warn("Mesh is null while emitting block quads for block {}", blockState.method_26204().method_9518().method_10851());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void emitItemQuads(class_1799 itemStack, Supplier<Random> supplier, RenderContext renderContext) {
/*  50 */     if (this.mesh != null) {
/*  51 */       renderContext.meshConsumer().accept(this.mesh);
/*     */     } else {
/*  53 */       Myron.LOGGER.warn("Mesh is null while emitting block quads for item {}", itemStack.method_7909().method_7848().method_10851());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 face, Random random) {
/*  59 */     if (this.backupQuads == null) {
/*  60 */       this.backupQuads = new ArrayList<>();
/*     */       
/*  62 */       this.mesh.forEach(quadView -> this.backupQuads.add(quadView.toBakedQuad(0, this.sprite, false)));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  67 */     return this.backupQuads;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_4708() {
/*  72 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_4712() {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_24304() {
/*  82 */     return this.isSideLit;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_4713() {
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1058 method_4711() {
/*  92 */     return this.sprite;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_809 method_4709() {
/*  97 */     return this.transformation;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_806 method_4710() {
/* 102 */     return class_806.field_4292;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVanillaAdapter() {
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/blackhole-1.0.1+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/client/model/MyronBakedModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */