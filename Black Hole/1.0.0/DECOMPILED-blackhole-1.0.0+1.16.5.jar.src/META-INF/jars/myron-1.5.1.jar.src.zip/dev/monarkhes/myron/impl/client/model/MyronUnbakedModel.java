/*     */ package dev.monarkhes.myron.impl.client.model;
/*     */ import com.mojang.datafixers.util.Pair;
/*     */ import de.javagl.obj.FloatTuple;
/*     */ import de.javagl.obj.Obj;
/*     */ import de.javagl.obj.ObjFace;
/*     */ import de.javagl.obj.ObjSplitting;
/*     */ import de.javagl.obj.ReadableObj;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import net.fabricmc.fabric.api.renderer.v1.Renderer;
/*     */ import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
/*     */ import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
/*     */ import net.minecraft.class_1058;
/*     */ import net.minecraft.class_1059;
/*     */ import net.minecraft.class_1087;
/*     */ import net.minecraft.class_1088;
/*     */ import net.minecraft.class_1100;
/*     */ import net.minecraft.class_1160;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3665;
/*     */ import net.minecraft.class_4590;
/*     */ import net.minecraft.class_4730;
/*     */ import net.minecraft.class_809;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class MyronUnbakedModel implements class_1100 {
/*  30 */   public static final class_4730 DEFAULT_SPRITE = new class_4730(class_1059.field_5275, null);
/*     */   
/*     */   private final Obj obj;
/*     */   private final Map<String, MyronMaterial> materials;
/*     */   private final class_809 transform;
/*  35 */   private final Collection<class_4730> textureDependencies = new HashSet<>();
/*     */   private final class_4730 sprite;
/*     */   private final boolean isSideLit;
/*     */   private final class_1160 offset;
/*     */   
/*     */   public MyronUnbakedModel(Obj obj, Map<String, MyronMaterial> materials, class_809 transform, boolean isSideLit, class_1160 offset) {
/*  41 */     this.obj = obj;
/*  42 */     this.materials = materials;
/*  43 */     this.transform = transform;
/*  44 */     this.isSideLit = isSideLit;
/*  45 */     this.offset = offset;
/*     */     
/*  47 */     for (MyronMaterial myronMaterial : materials.values()) {
/*  48 */       this.textureDependencies.add(new class_4730(class_1059.field_5275, myronMaterial.getTexture()));
/*     */     }
/*     */     
/*  51 */     MyronMaterial material = getMaterial("sprite");
/*  52 */     if (materials.size() > 0) {  } else {  }  this
/*     */ 
/*     */ 
/*     */       
/*  56 */       .sprite = DEFAULT_SPRITE;
/*     */   }
/*     */ 
/*     */   
/*     */   private MyronMaterial getMaterial(String name) {
/*  61 */     return this.materials.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<class_2960> method_4755() {
/*  66 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<class_4730> method_4754(Function<class_2960, class_1100> unbakedModelGetter, Set<Pair<String, String>> unresolvedTextureReferences) {
/*  71 */     return this.textureDependencies;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public class_1087 method_4753(class_1088 loader, Function<class_4730, class_1058> textureGetter, class_3665 settings, class_2960 modelId) {
/*  76 */     Renderer renderer = RendererAccess.INSTANCE.getRenderer();
/*     */     
/*  78 */     if (renderer == null) return null;
/*     */     
/*  80 */     MeshBuilder builder = renderer.meshBuilder();
/*  81 */     QuadEmitter emitter = builder.getEmitter();
/*     */     
/*  83 */     for (Map.Entry<String, Obj> entry : (Iterable<Map.Entry<String, Obj>>)ObjSplitting.splitByMaterialGroups((ReadableObj)this.obj).entrySet()) {
/*  84 */       Obj group = entry.getValue();
/*  85 */       MyronMaterial material = getMaterial(entry.getKey());
/*     */       
/*  87 */       if (material == null) {
/*  88 */         material = MyronMaterial.DEFAULT;
/*     */       }
/*     */       
/*  91 */       int materialColor = material.getColor();
/*  92 */       class_1058 sprite = textureGetter.apply(new class_4730(class_1059.field_5275, material.getTexture()));
/*     */       
/*  94 */       for (int faceIndex = 0; faceIndex < group.getNumFaces(); faceIndex++) {
/*  95 */         face(renderer, emitter, group, group.getFace(faceIndex), material, materialColor, sprite, settings);
/*     */       }
/*     */     } 
/*     */     
/*  99 */     return new MyronBakedModel(builder.build(), this.transform, textureGetter.apply(this.sprite), this.isSideLit);
/*     */   }
/*     */   
/*     */   private void face(Renderer renderer, QuadEmitter emitter, Obj group, ObjFace face, MyronMaterial material, int materialColor, class_1058 sprite, class_3665 settings) {
/* 103 */     if (face.getNumVertices() <= 4) {
/* 104 */       for (int vertex = 0; vertex < face.getNumVertices(); vertex++) {
/* 105 */         vertex(emitter, group, face, vertex, settings);
/*     */       }
/*     */       
/* 108 */       emit(renderer, emitter, material, materialColor, sprite, settings);
/*     */     } else {
/* 110 */       int vertices = face.getNumVertices();
/*     */ 
/*     */ 
/*     */       
/* 114 */       FloatTuple textureCoords = face.containsTexCoordIndices() ? group.getTexCoord(face.getTexCoordIndex(0)) : null;
/*     */       
/* 116 */       class_1160 pos = of(group.getVertex(face.getVertexIndex(0)));
/* 117 */       pos.method_23846(this.offset);
/* 118 */       class_1160 normal = of(group.getNormal(face.getNormalIndex(0)));
/*     */       
/* 120 */       rotate(settings, pos, normal);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       Vertex start = new Vertex(pos, normal, (textureCoords == null) ? 0.0F : textureCoords.getX(), (textureCoords == null) ? 0.0F : textureCoords.getY());
/*     */ 
/*     */       
/* 129 */       for (int vertex = 1; vertex < vertices - 1; vertex++) {
/* 130 */         vertex(emitter, 0, start.pos, start.normal, start.u, start.v);
/*     */ 
/*     */ 
/*     */         
/* 134 */         textureCoords = face.containsTexCoordIndices() ? group.getTexCoord(face.getTexCoordIndex(vertex)) : null;
/*     */         
/* 136 */         pos = of(group.getVertex(face.getVertexIndex(vertex)));
/* 137 */         pos.method_23846(this.offset);
/* 138 */         normal = of(group.getNormal(face.getNormalIndex(vertex)));
/*     */         
/* 140 */         rotate(settings, pos, normal);
/*     */         
/* 142 */         vertex(emitter, 1, pos, normal, 
/*     */ 
/*     */             
/* 145 */             (textureCoords == null) ? 0.0F : textureCoords.getX(), 
/* 146 */             (textureCoords == null) ? 0.0F : textureCoords.getY());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         textureCoords = face.containsTexCoordIndices() ? group.getTexCoord(face.getTexCoordIndex(vertex + 1)) : null;
/*     */         
/* 153 */         pos = of(group.getVertex(face.getVertexIndex(vertex + 1)));
/* 154 */         pos.method_23846(this.offset);
/* 155 */         normal = of(group.getNormal(face.getNormalIndex(vertex + 1)));
/*     */         
/* 157 */         rotate(settings, pos, normal);
/*     */ 
/*     */         
/* 160 */         vertex(emitter, 2, pos, normal, 
/*     */ 
/*     */             
/* 163 */             (textureCoords == null) ? 0.0F : textureCoords.getX(), 
/* 164 */             (textureCoords == null) ? 0.0F : textureCoords.getY());
/*     */ 
/*     */         
/* 167 */         vertex(emitter, 3, pos, normal, 
/*     */ 
/*     */             
/* 170 */             (textureCoords == null) ? 0.0F : textureCoords.getX(), 
/* 171 */             (textureCoords == null) ? 0.0F : textureCoords.getY());
/*     */ 
/*     */         
/* 174 */         emit(renderer, emitter, material, materialColor, sprite, settings);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void emit(Renderer renderer, QuadEmitter emitter, MyronMaterial material, int materialColor, class_1058 sprite, class_3665 settings) {
/* 180 */     emitter.material(material.getMaterial(renderer));
/* 181 */     emitter.spriteColor(0, materialColor, materialColor, materialColor, materialColor);
/* 182 */     emitter.colorIndex(material.getTintIndex());
/* 183 */     emitter.nominalFace(emitter.lightFace());
/*     */     
/* 185 */     if (material.getCullDirection() != null) {
/* 186 */       emitter.cullFace(material.getCullDirection());
/*     */     }
/*     */     
/* 189 */     boolean bl = (settings.method_3512() || material.isUvLocked());
/* 190 */     emitter.spriteBake(0, sprite, 0x20 | (bl ? 4 : 0));
/* 191 */     emitter.emit();
/*     */   }
/*     */   
/*     */   private void vertex(QuadEmitter emitter, Obj group, ObjFace face, int vertex, class_3665 settings) {
/* 195 */     class_1160 pos = of(group.getVertex(face.getVertexIndex(vertex)));
/*     */ 
/*     */     
/* 198 */     pos.method_23846(this.offset);
/* 199 */     class_1160 normal = of(group.getNormal(face.getNormalIndex(vertex)));
/*     */     
/* 201 */     float u = 0.0F, v = 0.0F;
/* 202 */     if (face.containsTexCoordIndices()) {
/* 203 */       FloatTuple textureCoords = group.getTexCoord(face.getTexCoordIndex(vertex));
/* 204 */       u = textureCoords.getX();
/* 205 */       v = textureCoords.getY();
/*     */     } 
/*     */     
/* 208 */     rotate(settings, pos, normal);
/*     */     
/* 210 */     vertex(emitter, vertex, pos, normal, u, v);
/*     */     
/* 212 */     if (face.getNumVertices() == 3) {
/* 213 */       vertex(emitter, vertex + 1, pos, normal, u, v);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void rotate(class_3665 settings, class_1160 pos, class_1160 normal) {
/* 218 */     if (settings.method_3509() != class_4590.method_22931()) {
/* 219 */       pos.method_4948(-0.5F, -0.5F, -0.5F);
/* 220 */       pos.method_19262(settings.method_3509().method_22937());
/* 221 */       pos.method_4948(0.5F, 0.5F, 0.5F);
/*     */       
/* 223 */       normal.method_19262(settings.method_3509().method_22937());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void vertex(QuadEmitter emitter, int vertex, class_1160 pos, class_1160 normal, float u, float v) {
/* 228 */     emitter.pos(vertex, pos);
/* 229 */     emitter.normal(vertex, normal);
/* 230 */     emitter.sprite(vertex, 0, u, v);
/*     */   }
/*     */   
/*     */   private static class_1160 of(FloatTuple tuple) {
/* 234 */     return new class_1160(tuple.getX(), tuple.getY(), tuple.getZ());
/*     */   }
/*     */   
/*     */   private static class Vertex {
/*     */     public final class_1160 pos;
/*     */     public final class_1160 normal;
/*     */     public final float u;
/*     */     public final float v;
/*     */     
/*     */     private Vertex(class_1160 pos, class_1160 normal, float u, float v) {
/* 244 */       this.pos = pos;
/* 245 */       this.normal = normal;
/* 246 */       this.u = u;
/* 247 */       this.v = v;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/1.0.0/blackhole-1.0.0+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/client/model/MyronUnbakedModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */