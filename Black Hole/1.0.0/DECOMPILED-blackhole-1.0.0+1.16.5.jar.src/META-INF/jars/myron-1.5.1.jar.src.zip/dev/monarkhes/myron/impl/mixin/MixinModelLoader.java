/*    */ package dev.monarkhes.myron.impl.mixin;
/*    */ 
/*    */ import dev.monarkhes.myron.impl.client.obj.ObjLoader;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.fabricmc.fabric.api.client.model.ModelProviderException;
/*    */ import net.fabricmc.fabric.api.client.model.ModelResourceProvider;
/*    */ import net.minecraft.class_1088;
/*    */ import net.minecraft.class_1100;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3300;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ @Mixin(value = {class_1088.class}, priority = 100)
/*    */ public abstract class MixinModelLoader
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_3300 field_5379;
/*    */   
/*    */   @Inject(method = {"loadModel"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void addObjModel(class_2960 id, CallbackInfo ci) {
/* 32 */     if (this.objModelProvider == null) {
/* 33 */       this.objModelProvider = (ModelResourceProvider)new ObjLoader(this.field_5379);
/*    */     }
/*    */     
/*    */     try {
/* 37 */       class_1100 model = this.objModelProvider.loadModelResource(id, null);
/*    */       
/* 39 */       if (model != null) {
/* 40 */         method_4729(id, model);
/* 41 */         ci.cancel();
/*    */       } 
/* 43 */     } catch (ModelProviderException e) {
/* 44 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   @Unique
/*    */   private ModelResourceProvider objModelProvider;
/*    */   
/*    */   @Shadow
/*    */   protected abstract void method_4729(class_2960 paramclass_2960, class_1100 paramclass_1100);
/*    */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/1.0.0/blackhole-1.0.0+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/mixin/MixinModelLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */