/*     */ package dev.monarkhes.myron.impl.client.model;
/*     */ 
/*     */ import net.fabricmc.fabric.api.renderer.v1.Renderer;
/*     */ import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
/*     */ import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
/*     */ import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2960;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public class MyronMaterial {
/*  12 */   public static final MyronMaterial DEFAULT = new MyronMaterial("missing_texture");
/*     */   
/*     */   static {
/*  15 */     DEFAULT.setTexture(new class_2960(""));
/*     */   }
/*     */ 
/*     */   
/*     */   public final String name;
/*  20 */   private int tintIndex = -1;
/*  21 */   private int color = -1;
/*     */   private class_2960 texture;
/*  23 */   private BlendMode blendMode = BlendMode.DEFAULT;
/*     */   
/*     */   private boolean uvLocked = false;
/*     */   
/*     */   private boolean diffuseShading = true;
/*     */   private boolean ambientOcclusion = true;
/*     */   private boolean emission = false;
/*     */   private boolean colorIndex = true;
/*     */   private RenderMaterial material;
/*     */   private class_2350 cullDirection;
/*     */   
/*     */   public MyronMaterial(String name) {
/*  35 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setTexture(class_2960 textureId) {
/*  39 */     this.texture = textureId;
/*     */   }
/*     */   
/*     */   public void setColor(float kd0, float kd1, float kd2) {
/*  43 */     this.color = -16777216;
/*  44 */     this.color |= (int)(255.0F * kd0) << 16;
/*  45 */     this.color |= (int)(255.0F * kd1) << 8;
/*  46 */     this.color |= (int)(255.0F * kd2);
/*     */   }
/*     */   
/*     */   public void setColor(int color) {
/*  50 */     this.color = color;
/*     */   }
/*     */   
/*     */   public int getColor() {
/*  54 */     return this.color;
/*     */   }
/*     */   
/*     */   public int getTintIndex() {
/*  58 */     return this.tintIndex;
/*     */   }
/*     */   
/*     */   public void setTintIndex(int tintIndex) {
/*  62 */     this.tintIndex = tintIndex;
/*     */   }
/*     */   
/*     */   public class_2960 getTexture() {
/*  66 */     return this.texture;
/*     */   }
/*     */   
/*     */   public void lockUv(boolean enabled) {
/*  70 */     this.uvLocked = enabled;
/*     */   }
/*     */   
/*     */   public boolean isUvLocked() {
/*  74 */     return this.uvLocked;
/*     */   }
/*     */   
/*     */   public void setBlendMode(BlendMode blendMode) {
/*  78 */     this.blendMode = blendMode;
/*     */   }
/*     */   
/*     */   public void setAmbientOcclusion(boolean enabled) {
/*  82 */     this.ambientOcclusion = enabled;
/*     */   }
/*     */   
/*     */   public void setEmissive(boolean enabled) {
/*  86 */     this.emission = enabled;
/*     */   }
/*     */   
/*     */   public void setDiffuseShading(boolean enabled) {
/*  90 */     this.diffuseShading = enabled;
/*     */   }
/*     */   
/*     */   public void setColorIndex(boolean enabled) {
/*  94 */     this.colorIndex = enabled;
/*     */   }
/*     */   
/*     */   public void cull(class_2350 direction) {
/*  98 */     this.cullDirection = direction;
/*     */   }
/*     */   @Nullable
/*     */   public class_2350 getCullDirection() {
/* 102 */     return this.cullDirection;
/*     */   }
/*     */   
/*     */   public RenderMaterial getMaterial(Renderer renderer) {
/* 106 */     if (this.material == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       MaterialFinder finder = renderer.materialFinder().blendMode(0, this.blendMode).disableAo(0, !this.ambientOcclusion).emissive(0, this.emission).disableDiffuse(0, !this.diffuseShading).disableColorIndex(0, !this.colorIndex);
/*     */       
/* 114 */       this.material = finder.find();
/*     */     } 
/*     */     
/* 117 */     return this.material;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     if (this.texture == null) {
/* 123 */       return this.name.hashCode();
/*     */     }
/* 125 */     return this.texture.hashCode();
/*     */   }
/*     */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/1.0.0/blackhole-1.0.0+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/client/model/MyronMaterial.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */