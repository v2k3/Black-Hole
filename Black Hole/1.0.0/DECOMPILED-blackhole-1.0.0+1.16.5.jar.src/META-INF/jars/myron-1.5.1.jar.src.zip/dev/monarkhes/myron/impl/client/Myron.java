/*    */ package dev.monarkhes.myron.impl.client;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashSet;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ import net.fabricmc.fabric.api.client.model.ModelLoadingRegistry;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3300;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class Myron implements ClientModInitializer {
/* 19 */   public static final Logger LOGGER = LogManager.getLogger("Myron");
/*    */   public static final String MOD_ID = "myron";
/*    */   
/*    */   public void onInitializeClient() {
/* 23 */     ModelLoadingRegistry.INSTANCE.registerResourceProvider(dev.monarkhes.myron.impl.client.obj.ObjLoader::new);
/* 24 */     ModelLoadingRegistry.INSTANCE.registerVariantProvider(dev.monarkhes.myron.impl.client.obj.ObjLoader::new);
/* 25 */     ModelLoadingRegistry.INSTANCE.registerModelProvider((manager, out) -> {
/*    */           Collection<class_2960> ids = new HashSet<>();
/*    */ 
/*    */           
/*    */           Collection<class_2960> candidates = new ArrayList<>();
/*    */ 
/*    */           
/*    */           candidates.addAll(manager.method_14488("models/block", ()));
/*    */ 
/*    */           
/*    */           candidates.addAll(manager.method_14488("models/item", ()));
/*    */ 
/*    */           
/*    */           candidates.addAll(manager.method_14488("models/misc", ()));
/*    */           
/*    */           for (class_2960 id : candidates) {
/*    */             if (id.method_12832().endsWith(".obj")) {
/*    */               ids.add(id);
/*    */               
/*    */               ids.add(new class_2960(id.method_12836(), id.method_12832().substring(0, id.method_12832().indexOf(".obj"))));
/*    */               
/*    */               continue;
/*    */             } 
/*    */             
/*    */             class_2960 test = new class_2960(id.method_12836(), id.method_12832() + ".obj");
/*    */             
/*    */             if (manager.method_18234(test)) {
/*    */               ids.add(id);
/*    */             }
/*    */           } 
/*    */           
/*    */           ids.forEach(());
/*    */         });
/*    */     
/* 59 */     LOGGER.info("Myron Initialized!");
/*    */   }
/*    */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/1.0.0/blackhole-1.0.0+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/impl/client/Myron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */