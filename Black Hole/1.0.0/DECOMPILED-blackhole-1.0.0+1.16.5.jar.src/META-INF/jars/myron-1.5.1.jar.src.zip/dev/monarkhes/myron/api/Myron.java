/*    */ package dev.monarkhes.myron.api;
/*    */ 
/*    */ import dev.monarkhes.myron.impl.mixin.BakedModelManagerAccessor;
/*    */ import net.minecraft.class_1087;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_310;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Myron
/*    */ {
/*    */   @Nullable
/*    */   public static class_1087 getModel(class_2960 id) {
/* 18 */     return (class_1087)((BakedModelManagerAccessor)class_310.method_1551().method_1554()).getModels().get(id);
/*    */   }
/*    */ }


/* Location:              /Users/alex/BAK/vini2003/Build/Black Hole/1.0.0/blackhole-1.0.0+1.16.5.jar!/META-INF/jars/myron-1.5.1.jar!/dev/monarkhes/myron/api/Myron.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */